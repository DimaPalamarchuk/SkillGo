import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score

#column_names = ["Kanal komunikacji", "Grupa docelowa", "Rabat", "Pora emisji", "Koszt dotarcia do klienta [zl]", "Skuteczność"]
data = [
    ["social media","nowi","tak","wieczór",18,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",42,"NIE"],
    ["social media","stali","tak","wieczór",15,"TAK"],
    ["wyszukiwarka","nowi","tak","dzień",38,"NIE"],
    ["social media","stali","tak","wieczór",14,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",45,"NIE"],
    ["social media","nowi","tak","wieczór",20,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",40,"NIE"],
    ["social media","stali","tak","wieczór",13,"TAK"],
    ["wyszukiwarka","stali","nie","dzień",35,"NIE"],
    ["social media","stali","tak","wieczór",16,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",44,"NIE"],
    ["social media","nowi","tak","wieczór",19,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",41,"NIE"],
    ["social media","stali","tak","wieczór",12,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",46,"NIE"],
    ["social media","stali","tak","wieczór",17,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",39,"NIE"],
    ["social media","stali","tak","wieczór",11,"TAK"],
    ["wyszukiwarka","nowi","nie","dzień",70,"NIE"]
]

print(data)

#X = np.array(dane)[:, 1:5]
#y = np.array(dane)[:, -1]

#print(X)
#print(y)

#X_encoder = LabelEncoder()

#X[:, 0] = X_encoder.fit_transform(X[:, 0])
#X[:, 1] = X_encoder.fit_transform(X[:, 1])
#X[:, 2] = X_encoder.fit_transform(X[:, 2])
#print(X)

#X.astype(float)
#scaler = MinMaxScaler()
#X = scaler.fit_transform(X)
#print(X)
#print(y)

maps = {
    "grupa": {"nowi":0, "stali":1},
    "rabat": {"nie":0, "tak":1},
    "pora": {"dzień":0, "wieczór":1},
    "skutecznosc": {"NIE":0, "TAK":1}
}

X, y = [], []

for row in data:
    X.append([
        maps["grupa"][row[1]],
        maps["rabat"][row[2]],
        maps["pora"][row[3]],
        row[4]
    ])
    y.append(maps["skutecznosc"][row[5]])

X = np.array(X, dtype=float)
y = np.array(y)

#print(X)
#print(y)

scaler = MinMaxScaler()
X = scaler.fit_transform(X)

mask = X[:,3] < 0.9
X = X[mask]
y = y[mask]

#print(X)
#print(y)

class Perceptron:
    def __init__(self, lr=0.1, epochs=20):
        self.lr = lr
        self.epochs = epochs

    def fit(self, X, y):
        self.w = np.zeros(X.shape[1] + 1)
        self.errors = []

        for _ in range(self.epochs):
            err = 0
            for xi, target in zip(X, y):
                y_hat = self.predict(xi)
                update = self.lr * (target - y_hat)
                self.w[1:] += update * xi
                self.w[0] += update
                err += int(update != 0)
            self.errors.append(err / len(X))
        return print(self.errors)

    def net(self, X):
        return np.dot(X, self.w[1:]) + self.w[0]

    def predict(self, X):
        return 1 if self.net(X) >= 0 else 0



X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = Perceptron(lr=0.1, epochs=60)
model.fit(X_train, y_train)

y_pred = np.array([model.predict(x) for x in X_test])
accuracy = accuracy_score(y_test, y_pred)

print("Dokładność klasyfikacji:", accuracy)


plt.plot(model.errors)
plt.xlabel("Epoka")
plt.ylabel("Błąd klasyfikacji")
plt.title("Proces uczenia perceptronu")
plt.grid()
plt.show()
